"use client"

import CoffeeApp from "../coffee-app"

export default function Page() {
  return <CoffeeApp />
}
